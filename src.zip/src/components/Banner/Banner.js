import { Button } from 'react-bootstrap'
import React from 'react'
import styled from 'styled-components'
import img1 from "../../assets/img3.png"

const Banner = () => {
  return (
    <Main>
        <div className='left'>
            <span>Buy from us today</span>
            <span>Lorem Ipsum some dummy text</span>
            <p>some text i dont even understand</p>
            <Button>Shop Now</Button>
        </div>
        <div>
            <img src={img1} />
        </div>
    </Main>
  )
}

export default Banner

const Main = styled.div`
display: flex;
justify-content: space-evenly;
align-items: center;
grid-template-columns: 1fr 1fr;
background-color: #d9c45285;
width: 100%;
height: auto;
padding:30px 0px;
margin-top: 20px;
overflow: hidden;
left span:nth-child(1) {
    font-size: 20px;
}
img {
    width: 400px; 
    height: 400px;
}
`